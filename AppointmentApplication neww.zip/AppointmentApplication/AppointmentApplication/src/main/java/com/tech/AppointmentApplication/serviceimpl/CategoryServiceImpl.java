package com.tech.AppointmentApplication.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tech.AppointmentApplication.model.Category;
import com.tech.AppointmentApplication.repository.CategoryRepository;
import com.tech.AppointmentApplication.service.CategoryService;

@Service
public class CategoryServiceImpl implements CategoryService {

    @Autowired
    private CategoryRepository categoryRepository;

    @Override
    public List<Category> getAllCategories() {
        return categoryRepository.findAll();
    }

    @Override
    public Category getCategoryById(Long id) {
        return categoryRepository.findById(id).orElse(null);
    }

    @Override
    public void addCategory(Category category) {
        // You may want to add validation logic before saving to the database
        categoryRepository.save(category);
    }

    @Override
    public void updateCategory(Category category) {
        // You may want to add validation logic before updating
        categoryRepository.save(category);
    }

    @Override
    public void deleteCategory(Long id) {
        categoryRepository.deleteById(id);
    }
}

