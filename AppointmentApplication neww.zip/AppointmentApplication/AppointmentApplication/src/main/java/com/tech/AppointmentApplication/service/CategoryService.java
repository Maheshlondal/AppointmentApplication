package com.tech.AppointmentApplication.service;

import java.util.List;

import com.tech.AppointmentApplication.model.Category;

public interface CategoryService {
    List<Category> getAllCategories();
    Category getCategoryById(Long id);
    void addCategory(Category category);
    void updateCategory(Category category);
    void deleteCategory(Long id);
}

