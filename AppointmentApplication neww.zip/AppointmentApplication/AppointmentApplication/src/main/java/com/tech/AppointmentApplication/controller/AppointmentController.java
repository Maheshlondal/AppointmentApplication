package com.tech.AppointmentApplication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tech.AppointmentApplication.model.Appointment;
import com.tech.AppointmentApplication.model.Category;
import com.tech.AppointmentApplication.model.User;
import com.tech.AppointmentApplication.service.AppointmentService;
import com.tech.AppointmentApplication.service.CategoryService;
import com.tech.AppointmentApplication.service.UserService;

@RestController
@RequestMapping("/appointments")
public class AppointmentController {

    @Autowired
    private AppointmentService appointmentService;
    
    @Autowired
    private UserService userService;

    @Autowired
    private CategoryService categoryService;

    @GetMapping("/current-and-previous-dates")
    public ResponseEntity<List<Appointment>> getAppointmentsForCurrentAndPreviousDates() {
        List<Appointment> appointments = appointmentService.getAppointmentsForCurrentAndPreviousDates();
        return ResponseEntity.ok(appointments);
    }

    @PostMapping("/book")
    public ResponseEntity<String> bookAppointment(@RequestParam String username, @RequestParam Long categoryId) {
        User user = userService.findByUsername(username);
        Category category = categoryService.getCategoryById(categoryId);

        if (user != null && category != null) {
            appointmentService.bookAppointment(user, category);
            return ResponseEntity.ok("Appointment booked successfully");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User or category not found");
        }
    }
}

