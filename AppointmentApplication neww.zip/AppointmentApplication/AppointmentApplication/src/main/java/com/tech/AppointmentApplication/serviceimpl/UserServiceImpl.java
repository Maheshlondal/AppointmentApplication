package com.tech.AppointmentApplication.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tech.AppointmentApplication.model.User;
import com.tech.AppointmentApplication.repository.UserRepository;
import com.tech.AppointmentApplication.service.UserService;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public void register(User user) {
        // You may want to validate user data before saving to the database
        userRepository.save(user);
    }

    @Override
    public User findByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    @Override
    public void changePassword(User user, String newPassword) {
        // You may want to add password validation logic before updating
        user.setPassword(newPassword);
        userRepository.save(user);
    }
}

