package com.tech.AppointmentApplication.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tech.AppointmentApplication.model.User;

public interface UserRepository extends JpaRepository<User, Long> {
    User findByUsername(String username);
}

