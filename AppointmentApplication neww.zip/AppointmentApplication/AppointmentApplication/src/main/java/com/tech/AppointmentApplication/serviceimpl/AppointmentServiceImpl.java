package com.tech.AppointmentApplication.serviceimpl;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tech.AppointmentApplication.model.Appointment;
import com.tech.AppointmentApplication.model.Category;
import com.tech.AppointmentApplication.model.User;
import com.tech.AppointmentApplication.repository.AppointmentRepository;
import com.tech.AppointmentApplication.repository.CategoryRepository;
import com.tech.AppointmentApplication.repository.UserRepository;
import com.tech.AppointmentApplication.service.AppointmentService;

@Service
public class AppointmentServiceImpl implements AppointmentService {

    private final AppointmentRepository appointmentRepository;
    private final UserRepository userRepository;
    private final CategoryRepository categoryRepository;

    @Autowired
    public AppointmentServiceImpl(AppointmentRepository appointmentRepository,
                                   UserRepository userRepository,
                                   CategoryRepository categoryRepository) {
        this.appointmentRepository = appointmentRepository;
        this.userRepository = userRepository;
        this.categoryRepository = categoryRepository;
    }

    @Override
    public List<Appointment> getAppointmentsForCurrentAndPreviousDates() {
        LocalDate currentDate = LocalDate.now();
        return appointmentRepository.findByDateBeforeOrDate(currentDate, currentDate);
    }

    @Override
    public void bookAppointment(User user, Category category) {
        // Validate user and category (add your validation logic here)

        // Create a new appointment
        Appointment appointment = new Appointment();
        appointment.setUser(user);
        appointment.setCategory(category);
        appointment.setDate(LocalDate.now());

        // Save the appointment to the repository
        appointmentRepository.save(appointment);
    }

    @Override
    public List<Appointment> getAdminAppointmentsForCurrentAndPreviousDates() {
        LocalDate currentDate = LocalDate.now();
        return appointmentRepository.findByDateBeforeOrDate(currentDate, currentDate);
    }
}
