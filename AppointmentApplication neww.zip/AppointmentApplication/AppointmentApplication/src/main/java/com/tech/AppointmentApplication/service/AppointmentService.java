package com.tech.AppointmentApplication.service;

import java.util.List;

import com.tech.AppointmentApplication.model.Appointment;
import com.tech.AppointmentApplication.model.Category;
import com.tech.AppointmentApplication.model.User;

public interface AppointmentService {
    // Retrieve appointments for the current and previous dates
    List<Appointment> getAppointmentsForCurrentAndPreviousDates();

    // Book an appointment for a user and category
    void bookAppointment(User user, Category category);

    // Retrieve admin-specific appointments for the current and previous dates
    List<Appointment> getAdminAppointmentsForCurrentAndPreviousDates();
}

