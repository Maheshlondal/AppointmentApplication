package com.tech.AppointmentApplication.service;

import com.tech.AppointmentApplication.model.User;

public interface UserService {
    void register(User user);
    User findByUsername(String username);
    void changePassword(User user, String newPassword);
}

